function v_cc(){
if ($('#inner-ember42').val().length >=16) {
if ($('#inner-ember44').val().length >=3) {
$('#ember51').removeClass('disabled');  $('#ember51').prop('disabled',false);
}else{$('#ember51').addClass('disabled'); $('#ember51').prop('disabled',true);}
}else{$('#ember51').addClass('disabled'); $('#ember51').prop('disabled',true);}
/* End */
}

setInterval(function(){ new v_cc(); }, 1000);